CREATE VIEW Customers AS
  SELECT
    `cu`.`customerName` AS `customerName`,
    `ad`.`address`      AS `address`,
    `ad`.`address2`     AS `address2`,
    `ci`.`city`         AS `city`,
    `ad`.`postalCode`   AS `postalCode`,
    `co`.`country`      AS `country`,
    `ad`.`phone`        AS `phone`,
    `cu`.`active`       AS `active`
  FROM (((`U01gMV`.`customer` `cu` LEFT JOIN `U01gMV`.`address` `ad`
      ON (((`cu`.`addressId` = `ad`.`addressId`) AND (`cu`.`createDate` = `ad`.`createDate`) AND
           (`cu`.`lastUpdate` = `ad`.`lastUpdate`)))) LEFT JOIN `U01gMV`.`city` `ci` ON ((
    (`cu`.`createDate` = `ci`.`createDate`) AND (`cu`.`lastUpdate` = `ci`.`lastUpdate`) AND
    (`cu`.`createdBy` = `ci`.`createdBy`) AND (`cu`.`lastUpdateBy` = `ci`.`lastUpdateBy`) AND
    (`ad`.`cityId` = `ci`.`cityId`)))) LEFT JOIN `U01gMV`.`country` `co` ON ((
    (`cu`.`createDate` = `co`.`createDate`) AND (`cu`.`lastUpdate` = `co`.`lastUpdate`) AND
    (`ad`.`createBy` = `co`.`createBy`) AND (`ad`.`lastUpdatedBy` = `co`.`lastUpdatedBy`) AND
    (`ci`.`countryId` = `co`.`countryId`))));
