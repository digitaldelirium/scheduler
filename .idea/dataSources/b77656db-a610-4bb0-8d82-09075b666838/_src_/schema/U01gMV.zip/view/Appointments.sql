CREATE VIEW Appointments AS
  SELECT
    `ap`.`title`        AS `title`,
    `ap`.`description`  AS `description`,
    `ap`.`location`     AS `location`,
    `ap`.`contact`      AS `contact`,
    `ap`.`url`          AS `url`,
    `cu`.`customerName` AS `customerName`,
    `ap`.`start`        AS `start`,
    `ap`.`end`          AS `end`,
    `ap`.`createDate`   AS `createDate`,
    `ap`.`createdBy`    AS `createdBy`,
    `ap`.`lastUpdate`   AS `lastUpdate`
  FROM (`U01gMV`.`appointment` `ap` LEFT JOIN `U01gMV`.`customer` `cu` ON ((
    (`ap`.`customerId` = `cu`.`customerId`) AND (`ap`.`createDate` = `cu`.`createDate`) AND
    (`ap`.`createdBy` = `cu`.`createdBy`) AND (`ap`.`lastUpdate` = `cu`.`lastUpdate`))));
